from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from pathlib import Path
import io, os, json, base64, hashlib
import numpy as np
from PIL import Image
try:
    import open_clip, torch
except Exception:
    open_clip=None; torch=None
from .fake_ai import embed as fake_embed
from .recall_parser import check_serial
from .dependencies import verify_token
from .db import get_db
from .models import User, DeviceRecord
from .crypto import encrypt

app = FastAPI()
from .security import apply_security
apply_security(app)
BASE = Path(__file__).resolve().parent
DEFECTS = BASE / 'data' / 'defects.json'

def _image_hash(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def _classify(b: bytes):
    if open_clip is None:
        vec = fake_embed(b)
        idx = int(abs(vec[0])*10) % 6
        types=["printer","smartphone","laptop","microwave","breadmaker","multicooker"]
        return types[idx], 0.65
    img = Image.open(io.BytesIO(b)).convert('RGB')
    model, preprocess, tok = open_clip.create_model_and_transforms("ViT-B-32", pretrained="laion2b_s34b_b79k")
    model.eval()
    im = preprocess(img).unsqueeze(0)
    with torch.no_grad():
        imf = model.encode_image(im)
        texts = [f"a photo of a {t}" for t in ["printer","smartphone","laptop","microwave","breadmaker","multicooker"]]
        tt = tok(texts)
        tf = model.encode_text(tt)
        imf = imf/imf.norm(dim=-1, keepdim=True)
        tf = tf/tf.norm(dim=-1, keepdim=True)
        logits = (100.0 * imf @ tf.T).softmax(dim=-1).cpu().numpy().ravel()
    i=int(np.argmax(logits))
    types=["printer","smartphone","laptop","microwave","breadmaker","multicooker"]
    return types[i], float(logits[i])

@app.post('/ai/classify')
async def classify(image: UploadFile = File(...), device_type_hint: str = Form('auto'), email: str = Form(None), serial: str = Form(None), _: str = Depends(verify_token), db = Depends(get_db)):
    b = await image.read()
    ih = _image_hash(b)
    dtype, conf = _classify(b) if device_type_hint=='auto' else (device_type_hint, 0.99)
    items = json.loads(DEFECTS.read_text(encoding='utf-8')).get(dtype, [])
    danger = any('предохран' in ' '.join(x.get('steps',[])).lower() for x in items)
    if email:
        try:
            u = User(email_enc=encrypt(email), serial_enc=encrypt(serial or ''), role='user')
            db.add(u)
            db.commit()
        except Exception:
            pass
    return JSONResponse({'device_type':dtype,'confidence':conf,'checklist':items,'image_hash':ih,'danger':danger})

@app.post('/ai/diag')
async def diag(image: UploadFile = File(...), device_type_hint: str = Form('auto'), _: str = Depends(verify_token)):
    res = await classify(image=image, device_type_hint=device_type_hint)
    raw = res.body
    data = json.loads(raw.decode('utf-8'))
    steps = []
    for item in data.get('checklist',[]):
        for s in item.get('steps',[]):
            steps.append(s)
    pdf = io.BytesIO(b"\n".join([x.encode('utf-8') for x in steps]) if steps else b"")
    b64 = base64.b64encode(pdf.getvalue()).decode('ascii')
    data['pdf_b64']=b64
    return JSONResponse(data)

@app.post('/scan_board')
async def scan_board(image: UploadFile = File(...)):
    b = await image.read()
    # dummy OCR
    ocr_text = 'SERIAL: PR-123456' 
    recall = check_serial('PR-123456')
    return JSONResponse({'ocr': ocr_text, 'tip': 'Проверить питание', 'recall': recall})

@app.post('/stt_fake')
async def stt_fake(payload: dict):
    return JSONResponse({'text': payload.get('hint','замена предохранителя')})

@app.post('/devices')
async def create_device(payload: dict, db = Depends(get_db), _: str = Depends(verify_token)):
    email = payload.get('email') or ''
    phone = payload.get('phone') or ''
    serial = payload.get('serial') or ''
    dtype = payload.get('device_type') or ''
    rec = DeviceRecord(email_enc=encrypt(email), phone_enc=encrypt(phone), serial_enc=encrypt(serial), device_type=dtype)
    db.add(rec)
    db.commit()
    return JSONResponse({'id': rec.id, 'device_type': rec.device_type, 'created_at': rec.created_at.isoformat()})

@app.get('/devices')
async def list_devices(db = Depends(get_db), _: str = Depends(verify_token)):
    items = db.query(DeviceRecord).order_by(DeviceRecord.id.desc()).limit(100).all()
    return JSONResponse([{'id': i.id, 'device_type': i.device_type, 'created_at': i.created_at.isoformat()} for i in items])