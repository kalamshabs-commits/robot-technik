from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi.responses import JSONResponse

def apply_security(app: FastAPI):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost", "https://localhost"],
        allow_methods=["POST", "GET"],
        allow_headers=["Authorization", "Content-Type"],
        allow_credentials=True,
    )
    limiter = Limiter(key_func=get_remote_address, default_limits=["100/10minute"]) 
    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response
    app.state.limiter = limiter
    @app.exception_handler(RateLimitExceeded)
    def rate_limit_handler(request: Request, exc: RateLimitExceeded):
        return JSONResponse({"error": "rate limited"}, status_code=429)
    return app