from fastapi import FastAPI, Request, UploadFile, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from .dependencies import RoleRequired
import json
import os
from pathlib import Path

app = FastAPI()
BASE = Path(__file__).resolve().parent
DEFECTS = BASE / "data" / "defects.json"

SCHEMA = {"type":"object","properties":{"type":{"type":"string","enum":["screen","battery","charging-port","motherboard","camera","button"]},"title":{"type":"string"},"steps":{"type":"array","items":{"type":"string"}}},"required":["type","title","steps"]}

HTML = """
<!doctype html><html><head>
<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
</head><body class=\"p-4\">
<h3>Админка: загрузка дефектов</h3>
<div class=\"mb-3\"><input id=\"file\" type=\"file\" class=\"form-control\" accept=\"application/json\"></div>
<button id=\"btn\" class=\"btn btn-primary\">Загрузить</button>
<pre id=\"out\" class=\"mt-3\"></pre>
<script>
async function upload(){
 const f=document.getElementById('file').files[0];
 if(!f){return}
 const txt=await f.text();
 let js;
 try{js=JSON.parse(txt);}catch(e){out.textContent='bad json';return}
 // simple schema check
 if(!js.type||!js.title||!Array.isArray(js.steps)){out.textContent='invalid schema';return}
 const fd=new FormData();
 const blob=new Blob([JSON.stringify(js)],{type:'application/json'});
 fd.append('file', blob, 'defect.json');
 const r=await fetch('/admin/upload', {method:'POST', body:fd});
 out.textContent=await r.text();
}
document.getElementById('btn').onclick=upload;
</script>
</body></html>
"""

@app.get('/admin/ui')
async def ui(_: str = Depends(RoleRequired('admin'))):
    return HTMLResponse(HTML)

@app.post('/admin/upload')
async def upload(request: Request, file: UploadFile|None=None, _: str = Depends(RoleRequired('admin'))):
    token=os.environ.get('ADMIN_TOKEN','')
    auth=request.headers.get('Authorization','')
    if not auth.startswith('Bearer ') or auth.split(' ',1)[1]!=token:
        return JSONResponse({'error':'unauthorized'}, status_code=401)
    if file is None:
        data=await request.json()
    else:
        data=json.loads(await file.read())
    if not isinstance(data, dict):
        return JSONResponse({'error':'invalid'}, status_code=400)
    DB=json.loads(DEFECTS.read_text(encoding='utf-8'))
    arr=DB.get(data.get('type',''), [])
    arr.append({"type":data.get('type'),"title":data.get('title'),"steps":data.get('steps',[])})
    DB[data.get('type','')]=arr
    DEFECTS.write_text(json.dumps(DB, ensure_ascii=False, indent=2), encoding='utf-8')
    return JSONResponse({'ok':True,'type':data.get('type')})